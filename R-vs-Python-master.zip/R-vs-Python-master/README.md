R-vs-Python
===========

This repository contains several code examples comparing R and Python for data science and visualization.
